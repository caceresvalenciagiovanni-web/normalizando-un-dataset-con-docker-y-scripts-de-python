# Proyecto de Normalización de Bases de Datos con Docker

Este proyecto automatiza el proceso de normalización (de CSV crudo a Scripts SQL 3FN) para tres datasets distintos: Netflix, E-commerce y Hospitales. Todo el entorno está contenerizado para garantizar su portabilidad.

## 📂 Estructura del Proyecto
```text
normalizacion-db/
├── docker-compose.yml      # Orquestación de servicios
├── Dockerfile              # Definición de imagen de Python
├── requirements.txt        # Dependencias (pandas, numpy)
├── README.md               # Documentación
├── raw/                    # [ENTRADA] Archivos CSV originales
├── sql/                    # [SALIDA] Scripts .sql generados
├── scripts/                # Lógica de normalización (Python)
│   ├── utils.py
│   ├── normalize_netflix.py
│   ├── normalize_ecommerce.py
│   └── normalize_hospital.py
└── docker-entrypoint/      # Scripts SQL iniciales
    └── init_dbs.sql        # Crea las DBs adicionales