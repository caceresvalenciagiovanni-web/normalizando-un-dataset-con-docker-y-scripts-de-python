CREATE DATABASE ecommerce_db;
CREATE DATABASE hospital_db;